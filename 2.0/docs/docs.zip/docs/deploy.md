# torch::deploy 已移至 pytorch/multipy [¶](#torch-deploy-has-been-moved-to-pytorch-multipy "永久链接到此标题")

> 译者：[片刻小哥哥](https://github.com/jiangzhonglian)
>
> 项目地址：<https://pytorch.apachecn.org/2.0/docs/deploy>
>
> 原始地址：<https://pytorch.org/docs/stable/deploy.html>


`torch::deploy` 已移至新家 <https://github.com/pytorch/multipy> 。