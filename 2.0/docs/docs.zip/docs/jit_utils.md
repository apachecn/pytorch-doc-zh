# JIT 实用程序 
- torch.utils.jit [¶](#module-torch.utils.jit "此标题的永久链接")

> 译者：[片刻小哥哥](https://github.com/jiangzhonglian)
>
> 项目地址：<https://pytorch.apachecn.org/2.0/docs/jit_utils>
>
> 原始地址：<https://pytorch.org/docs/stable/jit_utils.html>