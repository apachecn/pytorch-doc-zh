class MyDecisionGate(Module):
  __parameters__ = []
  training : bool
  def forward(self: __torch__.___torch_mangle_7.MyDecisionGate,
    x: Tensor) -> Tensor:
    _0 = torch.gt(torch.sum(x, dtype=None), 0)
    if bool(_0):
      _1 = x
    else:
      _1 = torch.neg(x)
    return _1
