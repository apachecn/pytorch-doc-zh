class WrapRNN(Module):
  __parameters__ = []
  training : bool
  loop : __torch__.___torch_mangle_18.MyRNNLoop
  def forward(self: __torch__.WrapRNN,
    argument_1: Tensor) -> Tensor:
    _0, y, = (self.loop).forward(argument_1, )
    return torch.relu(y)
